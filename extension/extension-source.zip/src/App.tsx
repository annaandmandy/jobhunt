import './App.css'
import ReviewEdit from './components/ReviewEdit'

function App() {
  return (
    <div className="app-container">
      <ReviewEdit />
    </div>
  )
}

export default App
